/**
 * Role
 * <p>
 * 23-Oct-18
 *
 * @author Gheoace Mihai
 */

package strategy;

public enum Role {
    COMMERCIANT, SHERIFF
}
